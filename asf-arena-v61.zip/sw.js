// ASF Arena V61 • rede primeiro com limite de tempo para o app (pega a versão nova, sem travar em rede lenta) + cache imediato para imagens e ícones
const C='asf-arena-v61',FILES=['./','./index.html','./manifest.json','./icon-192.png','./icon-512.png','./apple-touch-icon.png','./logo-oficial-asf.jpg','./fenix-asf.webp'];
const NET_TIMEOUT=3500;
const wait=ms=>new Promise((_,rej)=>setTimeout(()=>rej(new Error('timeout')),ms));
const store=(cache,req,res)=>{try{if(res&&res.status===200)cache.put(req,res.clone()).catch(()=>{})}catch(e){}};
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>Promise.all(FILES.map(f=>c.add(f).catch(()=>{})))).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==location.origin)return;
  const isDoc=r.mode==='navigate'||/\/(index\.html)?$/.test(u.pathname)||/\.(html|js|json)$/.test(u.pathname);
  e.respondWith((async()=>{
    const cache=await caches.open(C);
    if(isDoc){
      try{const res=await Promise.race([fetch(r),wait(NET_TIMEOUT)]);store(cache,r,res);return res}
      catch(err){return(await cache.match(r))||(await cache.match('./index.html'))||Response.error()}
    }
    // imagens e ícones: resposta imediata do cache e atualização em segundo plano
    const hit=await cache.match(r);
    const net=fetch(r).then(res=>{store(cache,r,res);return res}).catch(()=>null);
    return hit||(await net)||(await cache.match('./index.html'))||Response.error();
  })());
});
self.addEventListener('notificationclick',e=>{e.notification.close();e.waitUntil(clients.matchAll({type:'window',includeUncontrolled:true}).then(l=>{for(const c of l){if('focus'in c)return c.focus()}return clients.openWindow('./index.html')}))});
